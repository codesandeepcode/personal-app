"""Allows to serve Sphinx generated docs from django."""

__version__ = '0.3.3'

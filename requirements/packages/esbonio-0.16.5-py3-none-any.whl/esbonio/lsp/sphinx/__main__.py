import sys

from esbonio.cli import main
from esbonio.lsp.sphinx import cli

sys.exit(main(cli))

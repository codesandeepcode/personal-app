import sys

from esbonio.cli import main
from esbonio.lsp.rst import cli

sys.exit(main(cli))

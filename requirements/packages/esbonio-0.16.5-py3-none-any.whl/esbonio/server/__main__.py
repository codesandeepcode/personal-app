import sys

from esbonio.server.cli import main

sys.exit(main())
